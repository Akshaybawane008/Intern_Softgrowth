// cookiefooter.js — include on every page which you want to track images if cookies are accepted

function trackImagesIfCookiesAccepted() {
  if (localStorage.getItem("cookiesAccepted") === "true") {
    const existing = JSON.parse(localStorage.getItem("trackedImages") || "[]");
    const images = document.querySelectorAll("img");

    const newImages = Array.from(images).map(img => ({
      src: img.src,
      alt: img.alt,
      title: img.title,
      page: location.pathname,
      clickedAt: Date.now()
    }));

    const allImages = existing.concat(newImages);
    localStorage.setItem("trackedImages", JSON.stringify(allImages));
  }
}

trackImagesIfCookiesAccepted();
